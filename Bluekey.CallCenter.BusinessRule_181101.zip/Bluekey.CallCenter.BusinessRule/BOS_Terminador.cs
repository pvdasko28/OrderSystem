﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Terminador
    {

        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }

       
        public string Central { get; set; }

       
        public int Terminador { get; set; }
       
        public string Nombre_Terminador { get; set; }

        #region public methods

        public DataTable mgetConsultaTerminador()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                dset = dao.ExecuteDataSet("bos_sp_terminador", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;
            }
            return dtable;


        }

        #endregion
    }
}
