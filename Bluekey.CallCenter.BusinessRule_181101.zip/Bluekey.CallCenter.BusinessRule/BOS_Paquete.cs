﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;


namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Paquete
    {

        private string _errorMessage;
        private string _errorSource;
                
        public long Corporativo { get; set; }
                
        public string Central { get; set; }
                
        public long Paquete { get; set; }
                
        public long Platillo { get; set; }

        public int Cantidad { get; set; }

        #region public methods

        public DataTable mgetConsultaPaquete()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Platillo", this.Platillo);
                dset = dao.ExecuteDataSet("bos_sp_paquete", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;
            }
            return dtable;


        }

        #endregion
    }
}
