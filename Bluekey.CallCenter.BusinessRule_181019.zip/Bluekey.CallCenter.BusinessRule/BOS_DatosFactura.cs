﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_DatosFactura
    {
        private string _errorMessage;
        private string _errorSource;
       
        public long Corporativo { get; set; }
       
        public string RFC { get; set; }
        
        public string Codigo_Postal { get; set; }
        
        public string Razon_Social { get; set; }
       
        public string Nombre_Comercial { get; set; }
       
        public string Calle { get; set; }
       
        public string No_Exterior { get; set; }
        
        public string No_Interior { get; set; }
              
        public string Colonia { get; set; }
       
        public string Municipio { get; set; }
        
        public string Estado { get; set; }
       
        public string Pais { get; set; }

        #region public methods

        public DataTable mgetConsultaDatosFiscales()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@RFC", this.RFC);
                dset = dao.ExecuteDataSet("bos_sp_datosfiscales", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;


        }

        public bool insertaDatosFiscales()
        {
            bool returnValue = false;

            try
            {
                DataAccess dao = new DataAccess();

                SqlParameter[] parameters = new SqlParameter[12];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@RFC", this.RFC);
                parameters[2] = new SqlParameter("@CodigoPostal", this.Codigo_Postal);
                parameters[3] = new SqlParameter("@RazonSocial", this.Razon_Social);
                parameters[4] = new SqlParameter("@NombreComercial", this.Nombre_Comercial);
                parameters[5] = new SqlParameter("@Calle", this.Calle);
                parameters[6] = new SqlParameter("@NoExterior", this.No_Exterior);
                parameters[7] = new SqlParameter("@NoInterior", this.No_Interior);
                parameters[8] = new SqlParameter("@Colonia", this.Colonia);
                parameters[9] = new SqlParameter("@Municipio", this.Municipio);
                parameters[10] = new SqlParameter("@Estado", this.Estado);
                parameters[11] = new SqlParameter("@Pais", this.Pais);
                dao.ExecuteNonQuery("bos_spi_datosfiscales", parameters);

                returnValue = true;

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                returnValue = false;
            }
            return returnValue;
        }

        #endregion

    }
}
