﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;
namespace Bluekey.CallCenter.BusinessRule
{
    class BOS_Usuario
    {

        public long Corporativo { get; set; }

        public string Usuario { get; set; }

        public string Contrasena { get; set; }

        public string Nombre { get; set; }

        public int Perfil { get; set; }

        public bool Activo { get; set; }

        #region public methods
        public DataTable mgetConsultaUsuario()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Usuario", this.Usuario);
                dset = dao.ExecuteDataSet("bos_sp_usuario", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch
            {

            }
            return dtable;


        }
        #endregion
    }
}
