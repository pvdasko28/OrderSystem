﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Modificador
    {
     
        public long Corporativo { get; set; }
       
        public string Central { get; set; }

        public long Modificador { get; set; }
        
        public string Nombre_Modificador { get; set; }

        public long Clasificacion { get; set; }
       
        public decimal Precio { get; set; }

        #region public methods

        #endregion


    }
}
