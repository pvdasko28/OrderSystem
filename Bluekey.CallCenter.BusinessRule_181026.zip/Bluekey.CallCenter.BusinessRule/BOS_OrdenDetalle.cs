﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_OrdenDetalle
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }
        public string Central { get; set; }
        public long Orden { get; set; }
        public int Linea { get; set; }
        public long Platillo { get; set; }
        public string Nombre_Platillo { get; set; }
        public int Linea_Paquete { get; set; }
        public double Cantidad { get; set; }
        public decimal Precio { get; set; }
        public string Nota_Platillo { get; set; }
        public int Terminador { get; set; }
        public decimal Precio_Neto { get; set; }
        public decimal Servicio { get; set; }
        public decimal Descuento { get; set; }
        public double Descuento_Porcentaje { get; set; }
        public string Fecha_Captura_Platillo { get; set; }
        public bool Activo { get; set; }
        public string Usuario_Cancela { get; set; }
        public string Fecha_Cancela { get; set; }
        public string Nota_Cancela { get; set; }

    }
}
