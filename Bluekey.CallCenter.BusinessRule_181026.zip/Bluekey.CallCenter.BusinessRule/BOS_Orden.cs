﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Orden
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }
        public string Central { get; set; }
        public long Orden { get; set; }
        public string Sucursal { get; set; }
        public long Id_Cliente { get; set; }
        public int Id_Direccion { get; set; }
        public int Comensales { get; set; }
        public int Turno { get; set; }
        public string Nota { get; set; }
        public string Origen { get; set; }
        public string Forma_Pago { get; set; }
        public string Fecha_Captura_Inicio { get; set; }
        public string Operador_Captura { get; set; }
        public string Fecha_Captura_Fin { get; set; }
        public string Promesa_Entrega { get; set; }
        public string Estatus { get; set; }
        public long Repartidor { get; set; }
        public string Usuario_Cancela { get; set; }
        public string Fecha_Cancela { get; set; }
        public string Nota_Cancela { get; set; }
        public string RFC { get; set; }
        public string Codigo_Postal { get; set; }

        List<BOS_Orden> listaOrden = new List<BOS_Orden>();


    }
}
