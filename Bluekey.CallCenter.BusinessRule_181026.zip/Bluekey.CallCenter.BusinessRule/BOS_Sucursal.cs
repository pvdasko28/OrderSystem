﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Sucursal
    {
                
        public long Corporativo { get; set; }
        
        public string Central { get; set; }
       
        public string Sucursal { get; set; }
        
        public string Nombre_Sucursal { get; set; }
      
        public string RFC { get; set; }
        
        public string Razon_Social { get; set; }
        
        public string Calle { get; set; }
       
        public string No_Exterior { get; set; }
     
        public string No_Interior { get; set; }
      
        public string Colonia { get; set; }
        
        public string Municipio { get; set; }
      
        public string Estado { get; set; }

        public string Codigo_Postal { get; set; }
       
        public string Gerente { get; set; }
        
        public string Email { get; set; }
                
        public string Telefono { get; set; }
                
        public string Extension { get; set; }

        public bool Activo { get; set; }
                
        public string Contrasena { get; set; }

        #region public methods

        public DataTable mgetConsultaSucursales()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Sucursal", this.Sucursal);
                dset = dao.ExecuteDataSet("bos_sp_sucursal", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch
            {

            }
            return dtable;


        }


        #endregion

    }
}
