﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Orden : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOperador;
        string pTelefono;
        string pSucursal;
        int pIdCliente;
        int pIdDireccion;
        string pRFC;
        DateTime pHoraInicio;
        int pTurno;
        int lineaOrden;
        int lineaPlatillo;
        string lineaNombrePlatillo;
        int lineaPaquete;
        decimal lineaPrecio;

        //List<BOS_OrdenDetalle> listaOrdenDetalle = new List<BOS_OrdenDetalle>();

        public List<BOS_OrdenDetalle> listaOrdenDetalle
        {
            get
            {
                if (HttpContext.Current.Session["listaOrdenDetalle"] == null)
                {
                    HttpContext.Current.Session["listaOrdenDetalle"] = new List<BOS_OrdenDetalle>();
                }
                return HttpContext.Current.Session["listaOrdenDetalle"] as List<BOS_OrdenDetalle>;
            }
            set
            {
                HttpContext.Current.Session["listaOrdenDetalle"] = value;
            }

        }

        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getLoadQS();               
                populateMenu();
                populateGenerales();
                obtieneTurno();
                generaBtnGrupos();
                generaBtnPlatillos();                

            }
            else
            {

                pCorpo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                pCentral = HttpContext.Current.Session["sCentral"].ToString();
                pOperador = HttpContext.Current.Session["sOperador"].ToString();
                pTelefono = HttpContext.Current.Session["sTelefono"].ToString();
                pSucursal = HttpContext.Current.Session["sSucursal"].ToString();
                pIdCliente = int.Parse(HttpContext.Current.Session["sIdCli"].ToString());
                pIdDireccion = int.Parse(HttpContext.Current.Session["sIdDir"].ToString());
                pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());
                pRFC = HttpContext.Current.Session["sRFC"].ToString();
                pTurno = int.Parse(HttpContext.Current.Session["sTurno"].ToString());

                generaBtnGrupos();
                generaBtnPlatillos();    
            }
        }

       

        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];
            pSucursal = Request.QueryString["Suc"];
            pIdCliente = int.Parse(Request.QueryString["IdCli"].ToString());
            pIdDireccion = int.Parse(Request.QueryString["IdDir"].ToString());
            pHoraInicio = DateTime.Parse(Request.QueryString["HoraI"].ToString());
            pRFC = Request.QueryString["rfc"].ToString();


            Session["sCorpo"] = pCorpo;
            Session["sCentral"] = pCentral;
            Session["sOperador"] = pOperador;
            Session["sTelefono"] = pTelefono;
            Session["sSucursal"] = pSucursal;
            Session["sIdCli"] = pIdCliente;
            Session["sIdDir"] = pIdDireccion;
            Session["sHoraInicio"] = pHoraInicio;
            Session["sRFC"] = pRFC;

        }

        protected string ClientIDPageRedirect()
        {
            return this.paginaredirect.ClientID;
        }


        private void populateMenu()
        {
            DataTable tblCorp = new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();

            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            if (tblCorp.Rows.Count > 0)
                frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            if (tblClie.Rows.Count > 0)
                frmCentral = tblCent.Rows[0]["Nombre Central"].ToString();

            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblClie = objOper.mgetConsultaOperador();
            if (tblClie.Rows.Count > 0)
                frmOperador = tblClie.Rows[0]["Nombre"].ToString();

            BOS_ClienteDireccion objCli = new BOS_ClienteDireccion();
            objCli.Corporativo = pCorpo;
            objCli.Id_Cliente = pIdCliente;
            objCli.Id_Direccion = pIdDireccion;
            tblClie = objCli.mgetConsultaClienteDireccion();

            if (tblClie.Rows.Count > 0)
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString() + " " + tblClie.Rows[0]["Apellido"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }

            frmTelefono = pTelefono;
            pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());
            frmHoraIni = pHoraInicio.ToString("hh:mm tt");

        }

        private void populateGenerales()
        {
            DataTable dtable = new DataTable();
            BOS_Sucursal objSuc = new BOS_Sucursal();
            objSuc.Corporativo = pCorpo;
            objSuc.Central = pCentral;
            objSuc.Sucursal = pSucursal;
            dtable = objSuc.mgetConsultaSucursales();
            if (dtable.Rows.Count > 0)
            { 
                lblSucE.Text = dtable.Rows[0]["NombreSucursal"].ToString();
            
            }


        }

        private void obtieneTurno()
        {
            DataTable dtable = new DataTable();
            BOS_Turno objTurno = new BOS_Turno();
            objTurno.Corporativo = pCorpo;
            objTurno.Central = pCentral;
            objTurno.HoraTurno = pHoraInicio.ToString("yyyy-MM-dd HH:mm:ss");

            dtable = objTurno.mgetObtieneTurno();
            if (dtable.Rows.Count > 0)
            {
                pTurno = int.Parse(dtable.Rows[0]["Turno"].ToString());
                lblTurnoE.Text = dtable.Rows[0]["NombreTurno"].ToString();
                Session["sTurno"] = pTurno;
            }
        
        
        }

        private void generaBtnGrupos()
        {
           
            DataTable dtblTG = new DataTable();          
            BOS_TurnoGrupo objTurno = new BOS_TurnoGrupo();
            objTurno.Corporativo = pCorpo;
            objTurno.Central = pCentral;
            objTurno.Turno = pTurno;
            dtblTG = objTurno.mgetConsultaTurnosGrupos();
            if (dtblTG.Rows.Count > 0)
            {
                for (int i = 1; i < dtblTG.Rows.Count; i++)
                {

                    Button btnGpo = new Button();
                    btnGpo.Text = dtblTG.Rows[i]["NombreGrupo"].ToString();                    
                    btnGpo.ID = dtblTG.Rows[i]["Grupo"].ToString();
                    btnGpo.Font.Bold = true;
                    //btnGpo.ForeColor = System.Drawing.Color.White;
                    //btnGpo.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnGpo.Font.Size = 8;
                    btnGpo.CssClass = "btn btn-primary";
                    btnGpo.Width = Unit.Pixel(175);
                    btnGpo.Height = Unit.Pixel(30);                 
                    pnlGpo.Controls.Add(btnGpo);
                    pnlGpo.Visible = true;
                    
                    if (i % 2 == 0)
                    {
                        pnlGpo.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlGpo.Controls.Add(new LiteralControl("&nbsp;")); }

                    btnGpo.Click += new EventHandler(btnGpo_Click);

                }

                             
            }


        }

        void btnGpo_Click(object sender, EventArgs e)
        {
            DataTable dtblPG = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn =  sender as Button;
            int gpo = int.Parse(btn.ID.ToString());

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = gpo;
            objPla.Platillo = 0;
            dtblPG = objPla.mgetConsultaPlatillosGrupo();
            if (dtblPG.Rows.Count > 0)
            {

                for (int i = 1; i < dtblPG.Rows.Count; i++)
                {

                    Button btnPlaGpo = new Button();
                    btnPlaGpo.Text = dtblPG.Rows[i]["NombrePlatillo"].ToString();


                    btnPlaGpo.Font.Bold = true;
                    btnPlaGpo.ID = dtblPG.Rows[i]["Platillo"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnPlaGpo.Font.Size = 8;
                    btnPlaGpo.Width = Unit.Pixel(175);
                    btnPlaGpo.Height = Unit.Pixel(30);
                    btnPlaGpo.CssClass = "btn btn-info";
                    pnlPlatilloGpo.Controls.Add(btnPlaGpo);
                    pnlPlatilloGpo.Visible = true;
                    if (i % 2 == 0)
                    {
                        pnlPlatilloGpo.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlPlatilloGpo.Controls.Add(new LiteralControl("&nbsp;")); }
                    btnPlaGpo.Click += new EventHandler(btnPlaGpo_Click);

                }
               
                           
            }



        }

        private void generaBtnPlatillos()
        {
                      
            DataTable dtblTP = new DataTable();
            BOS_TurnoPlatillo objPlatillo = new BOS_TurnoPlatillo();
            objPlatillo.Corporativo = pCorpo;
            objPlatillo.Central = pCentral;
            objPlatillo.Turno = pTurno;
            dtblTP = objPlatillo.mgetConsultaTurnosPlatillo();
            if (dtblTP.Rows.Count > 0)
            {
            
                for (int i = 1; i < dtblTP.Rows.Count; i++)
                {

                    Button btnPla = new Button();
                    btnPla.Text = dtblTP.Rows[i]["NombrePlatillo"].ToString();


                    btnPla.Font.Bold = true;
                    btnPla.ID = dtblTP.Rows[i]["Platillo"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnPla.Font.Size = 8;
                    btnPla.Width = Unit.Pixel(175);
                    btnPla.Height = Unit.Pixel(30);
                    btnPla.CssClass = "btn btn-success";
                    pnlPla.Controls.Add(btnPla);
                    pnlPla.Visible = true;
                    if (i % 2 == 0)
                    {
                        pnlPla.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlPla.Controls.Add(new LiteralControl("&nbsp;")); }
                    btnPla.Click += new EventHandler(btnPla_Click);

                }
            }
                       


        }


        void btnPla_Click(object sender, EventArgs e)
        {
            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int pla = int.Parse(btn.ID.ToString());

           
            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pla;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {

                lineaPlatillo =  int.Parse( dtable.Rows[0]["Platillo"].ToString());
                lineaNombrePlatillo = dtable.Rows[0]["NombrePlatillo"].ToString();
                lineaPaquete =0;
                lineaPrecio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());

                agregaOrdenDetalle();
                refreshGrdOrden();
            }


        }
        
        void btnPlaGpo_Click(object sender, EventArgs e)
        {
            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int pla = int.Parse(btn.ID.ToString());

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pla;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {

                lineaPlatillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                lineaNombrePlatillo = dtable.Rows[0]["NombrePlatillo"].ToString();
                lineaPaquete = 0;
                lineaPrecio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());

                agregaOrdenDetalle();
                refreshGrdOrden();
            }
            
        }

        private void agregaOrden()
        {
            var objOrden = new BOS_Orden()
            {
                Corporativo = pCorpo,
                Central = pCentral,
                Orden = 1,
                Sucursal = pSucursal,
                Id_Cliente = pIdCliente,
                Id_Direccion = pIdDireccion,
                Comensales = 1,
                Turno = pTurno,
                Nota = "",
                Origen = "",
                Forma_Pago = "",
                Fecha_Captura_Inicio = pHoraInicio.ToString(),
                Operador_Captura = pOperador,
                Fecha_Captura_Fin = DateTime.Now.ToString(),
                Promesa_Entrega ="",
                Estatus="",
                Repartidor=0,
                Usuario_Cancela="",
                Fecha_Cancela="",
                Nota_Cancela="",
                RFC="",
                Codigo_Postal=""
                
            };

            Session["slistOrden"] = objOrden;
        
        }

        private void agregaOrdenDetalle()
        {
            BOS_OrdenDetalle ordenNueva = new BOS_OrdenDetalle();

            if (HttpContext.Current.Session["sLineaOrden"] != null)
            {
                lineaOrden = int.Parse(Session["sLineaOrden"].ToString());
                lineaOrden++;
            }
            else {
                lineaOrden = 1;
            }
            
                        
            ordenNueva.Corporativo = pCorpo;
            ordenNueva.Central = pCentral;
            ordenNueva.Linea = lineaOrden;
            ordenNueva.Platillo = lineaPlatillo;
            ordenNueva.Nombre_Platillo = lineaNombrePlatillo;
            ordenNueva.Cantidad = 1;
            ordenNueva.Precio = lineaPrecio;
            ordenNueva.Nota_Platillo = "";
            ordenNueva.Terminador = 1;
            ordenNueva.Precio_Neto = lineaPrecio;
            ordenNueva.Servicio = 0;
            ordenNueva.Descuento = 0;
            ordenNueva.Descuento_Porcentaje = 0;
            ordenNueva.Fecha_Captura_Platillo = DateTime.Now.ToString();
            ordenNueva.Activo = true;
            ordenNueva.Usuario_Cancela = "";
            ordenNueva.Fecha_Cancela = "";
            ordenNueva.Nota_Cancela = "";

            listaOrdenDetalle.Add(ordenNueva);
            Session["sLineaOrden"] = lineaOrden;
          
        }


        private void refreshGrdOrden()
        {
            grdCaptura.DataSource = listaOrdenDetalle;
            grdCaptura.DataBind();
            
        }

        protected void btnOrden_Click(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["sRFC"] != null)
            { pRFC = HttpContext.Current.Session["sRFC"].ToString(); }
            else { pRFC = ""; }

            if (pRFC == "")
            {
                lblMsgAlert.Text = "<strong>Debe seleccionar un RFC!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
            else
            {
                Response.Redirect("Orden.aspx?Corpo=" + pCorpo.ToString() + "&Central=" + pCentral + " &Oper=" + pOperador + "&Suc=" + pSucursal + " &IdCli=" + pIdCliente.ToString() + "&IdDir=" + pIdDireccion.ToString() + "&HoraI=" + pHoraInicio.ToString("hh:mm tt") + "&rfc=" + pRFC);
            }



        }



        private void showMessage(string msgA, string msgB, string St_Mensaje)
        {
            St_Mensaje = St_Mensaje + "\n" + msgA + "\n" + msgB;
            lblModalTitleError.Text = "Bluekey Order System";
            lblModalBodyError.Text = St_Mensaje;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModalError').modal();", true);
            upModalError.Update();

        }

    }
}