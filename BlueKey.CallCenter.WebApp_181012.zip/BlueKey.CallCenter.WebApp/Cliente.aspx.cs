﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Cliente : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOperador;
        string pTelefono;
        string pSucursal;
        DateTime pHoraInicio;
        int pIdCliente;
        int pIdDireccion;

        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getLoadQS();
                populateMenu();
                populateDirecciones();
                populateSucursales();
                //populateFechaNac();
            }
            else {

                pCorpo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                pCentral = HttpContext.Current.Session["sCentral"].ToString();
                pOperador = HttpContext.Current.Session["sOperador"].ToString();
                pTelefono = HttpContext.Current.Session["sTelefono"].ToString();
                pHoraInicio = DateTime.Parse( HttpContext.Current.Session["sHoraInicio"].ToString());

            }
        }

        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];

            Session["sCorpo"] = pCorpo;
            Session["sCentral"] = pCentral;
            Session["sOperador"] = pOperador;
            Session["sTelefono"] = pTelefono;


        }

        private void populateMenu()
        {
            DataTable tblCorp= new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();
            
            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            frmCentral = tblCent.Rows[0]["Nombre Central"].ToString();


            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblClie = objOper.mgetConsultaOperador();
            frmOperador = tblClie.Rows[0]["Nombre"].ToString();

            BOS_Cliente objClie = new BOS_Cliente();
            objClie.Corporativo = pCorpo;
            objClie.Telefono_Cliente = pTelefono;
            tblClie = objClie.mgetConsultaClienteDirecciones();

            if (tblClie.Rows.Count > 0) 
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }
                                    
            frmTelefono = pTelefono;

            if (pHoraInicio != null)
                pHoraInicio = DateTime.Now;
            
            
            Session["sHoraInicio"] = pHoraInicio.ToString("hh:mm tt");
            frmHoraIni = pHoraInicio.ToString ("hh:mm tt");


        }

        private void populateDirecciones()
        {
            BOS_Cliente objCliente = new BOS_Cliente();
            objCliente.Corporativo = pCorpo;
            objCliente.Telefono_Cliente = pTelefono;
            grdDir.DataSource = objCliente.mgetConsultaClienteDirecciones();
            grdDir.DataBind();
        }

        private void populateSucursales()
        {
            DataTable tblSuc = new DataTable();
            BOS_Sucursal objSuc = new BOS_Sucursal();
            objSuc.Corporativo = pCorpo;
            objSuc.Central = pCentral;
            objSuc.Sucursal = "";
            tblSuc = objSuc.mgetConsultaSucursales();

            ddlSuc.Items.Clear();
            ddlSuc.Items.Add(new ListItem { Text = "Seleccione Sucursal", Value = "" });
            ddlSuc.AppendDataBoundItems = true;
            ddlSuc.DataSource = tblSuc;
            ddlSuc.DataTextField = "Nombre Sucursal";
            ddlSuc.DataValueField = "Sucursal";
            ddlSuc.DataBind();



        }
        //private void populateFechaNac()
        //{

            
        //    ddlDia.Items.Clear();
        //    ddlDia.Items.Add(new ListItem { Text = "Dia", Value = "" });
        //    for (int  i = 1; i<32; i++ )
        //    {
        //        ddlDia.Items.Add(new ListItem { Text = i.ToString(), Value = i.ToString() });
        //    }

        //    ddlMes.Items.Clear();
        //    ddlMes.Items.Add(new ListItem { Text = "Mes",      Value = "" });
        //    ddlMes.Items.Add(new ListItem { Text = "Enero",    Value = "01" });
        //    ddlMes.Items.Add(new ListItem { Text = "Febrero",  Value = "02" });
        //    ddlMes.Items.Add(new ListItem { Text = "Marzo",    Value = "03" });
        //    ddlMes.Items.Add(new ListItem { Text = "Abril",    Value = "04" });
        //    ddlMes.Items.Add(new ListItem { Text = "Mayo",     Value = "05" });
        //    ddlMes.Items.Add(new ListItem { Text = "Junio",    Value = "06" });
        //    ddlMes.Items.Add(new ListItem { Text = "Julio",    Value = "07" });
        //    ddlMes.Items.Add(new ListItem { Text = "Agosto",   Value = "08" });
        //    ddlMes.Items.Add(new ListItem { Text = "Septiembre",Value = "09" });
        //    ddlMes.Items.Add(new ListItem { Text = "Octubre",  Value = "10" });
        //    ddlMes.Items.Add(new ListItem { Text = "Noviembre",Value = "11" });
        //    ddlMes.Items.Add(new ListItem { Text = "Diciembre",Value = "12" });


        //    int aniofin = 0;
        //    aniofin = int.Parse(DateTime.Now.Year.ToString());
        //    ddlAnio.Items.Clear();
        //    ddlAnio.Items.Add(new ListItem { Text = "Año", Value = "" });
        //    for (int k = 1900; k < aniofin - 10; k++)
        //    {
        //        ddlAnio.Items.Add(new ListItem { Text = k.ToString (), Value = k.ToString()});

        //    }

        //}

        protected void ddlSuc_SelectedIndexChanged(object sender, EventArgs e)
        {
            pSucursal = ddlSuc.SelectedItem.Value.ToString();
            Session["sSucursal"] = pSucursal;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
          
            int idCliente = 0;
            int idClienteDireccion = 0;
            BOS_Cliente objCliente = new BOS_Cliente();
            BOS_ClienteDireccion objCliDir = new BOS_ClienteDireccion();
            pSucursal = HttpContext.Current.Session["sSucursal"].ToString();

            try
            {
                objCliente.Corporativo = pCorpo;
                objCliente.Telefono_Cliente = pTelefono;
                objCliente.Telefono_Celular = txtCel.Text;
                objCliente.Telefono_Extra = txtTel.Text;
                objCliente.Nombre = txtNombre.Text;
                objCliente.Apellido = txtApellido.Text;
                objCliente.Email = txtEmail.Text;
                objCliente.Fecha_Nacimiento = txtFec.Text;
                idCliente = objCliente.insertaCliente();


                objCliDir.Corporativo = pCorpo;
                objCliDir.Id_Cliente = idCliente;
                objCliDir.Codigo_Postal = txtCP.Text;
                objCliDir.Calle = txtCalle.Text;
                objCliDir.No_Exterior = txtNumE.Text;
                objCliDir.No_Interior = txtNumI.Text;
                objCliDir.Colonia = txtCol.Text;
                objCliDir.Municipio = txtMpio.Text;
                objCliDir.Estado = txtEdo.Text;
                objCliDir.Entre_Calles = txtEnt.Text;
                objCliDir.Referencia = txtRef.Text;
                idClienteDireccion = objCliDir.insertaClienteDireccion();

                

            }
            catch (Exception Ex)
            {
                String A = Ex.Message;
                String B = Ex.Source;
                showMessage(A, B, "Error al insertar datos del Cliente");

            }            
                 

        }

        private void showMessage(string msgA, string msgB, string title)
        {
            String St_Mensaje = "";
            St_Mensaje = "Error al insertar datos cliente \n" + msgA + "\n" + msgB;
            lblModalTitle.Text = "Bluekey Order System";
            lblModalBody.Text = St_Mensaje;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            upModal.Update();

        }

        protected void btnOrden_Click(object sender, EventArgs e)
        {
            //Response.Redirect("DatosFiscales.aspx?Corpo= " + pCorpo.ToString () + "&Central= " + pCentral + "&Oper= " + pCorpo + "&Tel="+ pTelefono + "&Suc= " + pSucursal + " &sIdCli= " + pIdCliente.ToString() + "&IdDir= " + pIdDireccion.ToString()) ;
            Response.Redirect("DatosFiscales.aspx?Corpo=1&Central=cdmx&Oper=1mx0004&Tel=88&Suc=Sate&IdCli=8&IdDir=1&HoraI=" + pHoraInicio.ToString ("hh:mm tt") );
        }
    }
}