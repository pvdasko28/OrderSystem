﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Orden : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOperador;
        string pTelefono;
        string pSucursal;
        DateTime pHoraInicio;
        int pIdCliente;
        int pIdDireccion;

        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getLoadQS();
                populateMenu();
                populateGenerales();
                //populateDirecciones();
                //populateSucursales();
                //populateFechaNac();
            }
            else
            {

                pCorpo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                pCentral = HttpContext.Current.Session["sCentral"].ToString();
                pOperador = HttpContext.Current.Session["sOperador"].ToString();
                pTelefono = HttpContext.Current.Session["sTelefono"].ToString();
                pSucursal = HttpContext.Current.Session["sSucursal"].ToString();
                pIdCliente = int.Parse(HttpContext.Current.Session["sIdCli"].ToString());
                pIdDireccion = int.Parse(HttpContext.Current.Session["sIdDir"].ToString());
                pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());

            }
        }


        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];
            pSucursal = Request.QueryString["Suc"];
            pIdCliente = int.Parse(Request.QueryString["IdCli"].ToString());
            pIdDireccion = int.Parse(Request.QueryString["IdDir"].ToString());
            pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());


            Session["sCorpo"] = pCorpo;
            Session["sCentral"] = pCentral;
            Session["sOperador"] = pOperador;
            Session["sTelefono"] = pTelefono;
            Session["sSucursal"] = pSucursal;
            Session["sIdCli"] = pIdCliente;
            Session["sIdDir"] = pIdDireccion;
            Session["sHoraInicio"] = pHoraInicio; 

        }

        private void populateMenu()
        {
            DataTable tblCorp = new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();

            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            frmCentral = tblCent.Rows[0]["Nombre Central"].ToString();


            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblClie = objOper.mgetConsultaOperador();
            frmOperador = tblClie.Rows[0]["Nombre"].ToString();

            BOS_Cliente objClie = new BOS_Cliente();
            objClie.Corporativo = pCorpo;
            objClie.Telefono_Cliente = pTelefono;
            tblClie = objClie.mgetConsultaClienteDirecciones();

            if (tblClie.Rows.Count > 0)
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }

            frmTelefono = pTelefono;
            pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());
            frmHoraIni = pHoraInicio.ToString("hh:mm tt");

        }

        private void populateGenerales()
        {
            DataTable dtable = new DataTable();
            BOS_Sucursal objSuc = new BOS_Sucursal();
            objSuc.Corporativo = pCorpo;
            objSuc.Central = pCentral;
            objSuc.Sucursal = pSucursal;
            dtable = objSuc.mgetConsultaSucursales();

            lblSucE.Text = dtable.Rows[0]["Nombre Sucursal"].ToString();
            lblTelE.Text = pTelefono;

        }


    }
}