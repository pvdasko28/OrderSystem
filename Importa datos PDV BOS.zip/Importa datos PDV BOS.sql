--Carga de pdv a BD BOS
--turnos 
insert into  [dbo].[C_Turnos]

select 1,	'cdmx',	1,	'Desayuno',	'1900-01-01 07:00:00',	'1900-01-01 12:59:00'
union
select 1,	'cdmx',	2,	'Comida',	'1900-01-01 13:00:00',	'1900-01-01 17:59:00'
union
select 1,	'cdmx',	3,	'Cena',	'1900-01-01 18:00:00',	'1900-01-01 23:00:00'


--grupos
insert into [dbo].[C_Grupos]
select 
1, 
'cdmx',
num_grupo,
desc_grupo,
Color,
Lu,
Ma,
Mi,
Ju,
Vi,
Sa,
DO,
1
from [Bluekey_PuntoVenta].[dbo].[GRUPOS]

--platillos
insert Into [dbo].[C_Platillos]
select
1, 
'cdmx',
Pla,
Des,
Gpo,
Tipo,
Ser,
Coman,
Mod,
0,
Ter,
Tiempo,
Pre,
isnull (Desglosa_Servicio,0),
Paq,
Prom,
Color,
1
 from [Bluekey_PuntoVenta].[dbo].[PLATILLOS]


 --Turnos
 select * from [dbo].[C_Turnos]
 
 --Turnos Grupos
insert into [dbo].[C_Turnos Grupos] --1
select 1, 'cdmx',Tur , ROW_NUMBER() OVER(ORDER BY Num_Grupo asc) AS 'Orden',   Num_Grupo
 from [Bluekey_PuntoVenta].[dbo].[TURNOS]
 UNPIVOT (
	GrupoNum
	FOR [Grupo] IN (G1	,G2	,G3	,G4	,G5	,G6	,G7	,G8	,G9	,G10	,G11	,G12	,G13	,G14	,G15	,G16	,G17	,G18	,G19	,G20	,G21	,G22	,G23	,G24	,G25	,G26	,G27	,G28	,G29	,G30	,G31	,G32	,G33	,G34	,G35	,G36	,G37	,G38	,G39	,G40	,G41	,G42	,G43	,G44	,G45	,G46	,G47	,G48	,G49	,G50	
	,G51	,G52	,G53	,G54	,G55	,G56	,G57	,G58	,G59	,G60	,G61	,G62	,G63	,G64	,G65	,G66	,G67	,G68	,G69	,G70	,G71	,G72	,G73	,G74	,G75	,G76	,G77	,G78	,G79	,G80	,G81	,G82	,G83	,G84	,G85	,G86	,G87	,G88	,G89	,G90	,G91	,G92	,G93	,G94	,G95	,G96	,G97	,G98	,G99	,G100	
	,G101	,G102	,G103	,G104	,G105	,G106	,G107	,G108	,G109	,G110	,G111	,G112	,G113	,G114	,G115	,G116	,G117	,G118	,G119	,G120	,G121	,G122	,G123	,G124	,G125	,G126	,G127	,G128	,G129	,G130	,G131	,G132	,G133	,G134	,G135	,G136	,G137	,G138	,G139	,G140	,G141	,G142	,G143	,G144	,G145	,G146	,G147	,G148	,G149	,G150	
	,G151	,G152	,G153	,G154	,G155	,G156	,G157	,G158	,G159	,G160	,G161	,G162	,G163	,G164	,G165	,G166	,G167	,G168	,G169	,G170	,G171	,G172	,G173	,G174	,G175	,G176	,G177	,G178	,G179	,G180	,G181	,G182	,G183	,G184	,G185	,G186	,G187	,G188	,G189	,G190	,G191	,G192	,G193	,G194	,G195	,G196	,G197	,G198	,G199	,G200

		)
	) as P	
	INNER JOIN [Bluekey_PuntoVenta].[dbo].[GRUPOS] ON GrupoNum = Num_Grupo 
where Clave_PDV = 'REST' 
 and GrupoNum != 0 AND Tur =1 
 --group by  Tur ,  Num_Grupo, Desc_Grupo 
Order by   Num_Grupo

insert into [dbo].[C_Turnos Grupos] --2
select 1, 'cdmx',Tur , ROW_NUMBER() OVER(ORDER BY Num_Grupo asc) AS 'Orden',   Num_Grupo
 from [Bluekey_PuntoVenta].[dbo].[TURNOS]
 UNPIVOT (
	GrupoNum
	FOR [Grupo] IN (G1	,G2	,G3	,G4	,G5	,G6	,G7	,G8	,G9	,G10	,G11	,G12	,G13	,G14	,G15	,G16	,G17	,G18	,G19	,G20	,G21	,G22	,G23	,G24	,G25	,G26	,G27	,G28	,G29	,G30	,G31	,G32	,G33	,G34	,G35	,G36	,G37	,G38	,G39	,G40	,G41	,G42	,G43	,G44	,G45	,G46	,G47	,G48	,G49	,G50	
	,G51	,G52	,G53	,G54	,G55	,G56	,G57	,G58	,G59	,G60	,G61	,G62	,G63	,G64	,G65	,G66	,G67	,G68	,G69	,G70	,G71	,G72	,G73	,G74	,G75	,G76	,G77	,G78	,G79	,G80	,G81	,G82	,G83	,G84	,G85	,G86	,G87	,G88	,G89	,G90	,G91	,G92	,G93	,G94	,G95	,G96	,G97	,G98	,G99	,G100	
	,G101	,G102	,G103	,G104	,G105	,G106	,G107	,G108	,G109	,G110	,G111	,G112	,G113	,G114	,G115	,G116	,G117	,G118	,G119	,G120	,G121	,G122	,G123	,G124	,G125	,G126	,G127	,G128	,G129	,G130	,G131	,G132	,G133	,G134	,G135	,G136	,G137	,G138	,G139	,G140	,G141	,G142	,G143	,G144	,G145	,G146	,G147	,G148	,G149	,G150	
	,G151	,G152	,G153	,G154	,G155	,G156	,G157	,G158	,G159	,G160	,G161	,G162	,G163	,G164	,G165	,G166	,G167	,G168	,G169	,G170	,G171	,G172	,G173	,G174	,G175	,G176	,G177	,G178	,G179	,G180	,G181	,G182	,G183	,G184	,G185	,G186	,G187	,G188	,G189	,G190	,G191	,G192	,G193	,G194	,G195	,G196	,G197	,G198	,G199	,G200

		)
	) as P	
	INNER JOIN [Bluekey_PuntoVenta].[dbo].[GRUPOS] ON GrupoNum = Num_Grupo 
where Clave_PDV = 'REST' 
 and GrupoNum != 0 AND Tur = 2 
 --group by  Tur ,  Num_Grupo, Desc_Grupo 
Order by   Num_Grupo


insert into [dbo].[C_Turnos Grupos] --3
select 1, 'cdmx',Tur , ROW_NUMBER() OVER(ORDER BY Num_Grupo asc) AS 'Orden',   Num_Grupo
 from [Bluekey_PuntoVenta].[dbo].[TURNOS]
 UNPIVOT (
	GrupoNum
	FOR [Grupo] IN (G1	,G2	,G3	,G4	,G5	,G6	,G7	,G8	,G9	,G10	,G11	,G12	,G13	,G14	,G15	,G16	,G17	,G18	,G19	,G20	,G21	,G22	,G23	,G24	,G25	,G26	,G27	,G28	,G29	,G30	,G31	,G32	,G33	,G34	,G35	,G36	,G37	,G38	,G39	,G40	,G41	,G42	,G43	,G44	,G45	,G46	,G47	,G48	,G49	,G50	
	,G51	,G52	,G53	,G54	,G55	,G56	,G57	,G58	,G59	,G60	,G61	,G62	,G63	,G64	,G65	,G66	,G67	,G68	,G69	,G70	,G71	,G72	,G73	,G74	,G75	,G76	,G77	,G78	,G79	,G80	,G81	,G82	,G83	,G84	,G85	,G86	,G87	,G88	,G89	,G90	,G91	,G92	,G93	,G94	,G95	,G96	,G97	,G98	,G99	,G100	
	,G101	,G102	,G103	,G104	,G105	,G106	,G107	,G108	,G109	,G110	,G111	,G112	,G113	,G114	,G115	,G116	,G117	,G118	,G119	,G120	,G121	,G122	,G123	,G124	,G125	,G126	,G127	,G128	,G129	,G130	,G131	,G132	,G133	,G134	,G135	,G136	,G137	,G138	,G139	,G140	,G141	,G142	,G143	,G144	,G145	,G146	,G147	,G148	,G149	,G150	
	,G151	,G152	,G153	,G154	,G155	,G156	,G157	,G158	,G159	,G160	,G161	,G162	,G163	,G164	,G165	,G166	,G167	,G168	,G169	,G170	,G171	,G172	,G173	,G174	,G175	,G176	,G177	,G178	,G179	,G180	,G181	,G182	,G183	,G184	,G185	,G186	,G187	,G188	,G189	,G190	,G191	,G192	,G193	,G194	,G195	,G196	,G197	,G198	,G199	,G200

		)
	) as P	
	INNER JOIN [Bluekey_PuntoVenta].[dbo].[GRUPOS] ON GrupoNum = Num_Grupo 
where Clave_PDV = 'REST' 
 and GrupoNum != 0 AND Tur = 3
 --group by  Tur ,  Num_Grupo, Desc_Grupo 
Order by   Num_Grupo


--Turnos platillos
insert into [dbo].[C_Turnos Platillos] --1
select  1, 'cdmx', Tur, ROW_NUMBER() OVER(ORDER BY Platillo asc) AS 'Orden', Platillo
 from [Bluekey_PuntoVenta].[dbo].[TURNOS]
 UNPIVOT (
	Platillo
	FOR [Boton] IN (B1	,B2	,B3	,B4	,B5	,B6	,B7	,B8	,B9	,B10	
	,B11	,B12	,B13	,B14	,B15	,B16	,B17	,B18	,B19	,B20	,B21	,B22	,B23	,B24)
)as P
	INNER JOIN [Bluekey_PuntoVenta].[dbo].[PLATILLOS] ON Pla = Platillo
where Clave_PDV = 'REST' 
and Tur = 1
and Platillo != 0
Order by   Platillo

insert into [dbo].[C_Turnos Platillos] --2
select  1, 'cdmx', Tur, ROW_NUMBER() OVER(ORDER BY Platillo asc) AS 'Orden', Platillo
 from [Bluekey_PuntoVenta].[dbo].[TURNOS]
 UNPIVOT (
	Platillo
	FOR [Boton] IN (B1	,B2	,B3	,B4	,B5	,B6	,B7	,B8	,B9	,B10	
	,B11	,B12	,B13	,B14	,B15	,B16	,B17	,B18	,B19	,B20	,B21	,B22	,B23	,B24)
)as P
	INNER JOIN [Bluekey_PuntoVenta].[dbo].[PLATILLOS] ON Pla = Platillo
where Clave_PDV = 'REST' 
and Tur = 2
and Platillo != 0
Order by   Platillo

insert into [dbo].[C_Turnos Platillos] --3
select  1, 'cdmx', Tur, ROW_NUMBER() OVER(ORDER BY Platillo asc) AS 'Orden', Platillo
 from [Bluekey_PuntoVenta].[dbo].[TURNOS]
 UNPIVOT (
	Platillo
	FOR [Boton] IN (B1	,B2	,B3	,B4	,B5	,B6	,B7	,B8	,B9	,B10	
	,B11	,B12	,B13	,B14	,B15	,B16	,B17	,B18	,B19	,B20	,B21	,B22	,B23	,B24)
)as P
	INNER JOIN [Bluekey_PuntoVenta].[dbo].[PLATILLOS] ON Pla = Platillo
where Clave_PDV = 'REST' 
and Tur = 3
and Platillo != 0
Order by   Platillo

--EQUIVALENCIAS 
insert into [dbo].[C_Platillos Equivalencias]
select 1, 'cdmx',Platillo , Descripcion, Platillo_Equivalente
 from [Bluekey_PuntoVenta].[dbo].[EQUIVALENCIAS]




 --OBTIENE TURNOS
 declare @Hora time
SET @Hora =  cAST (CURRENT_TIMESTAMP   as TIME)

print @Hora

select 
Corporativo,
Central,
Turno,
[Nombre Turno] AS NombreTurno,
 CAST ( [Hora Inicio] AS TIME) as HoraInicio ,
 CAST ( [Hora Fin] AS TIME) AS HoraFin
 from  [dbo].[C_Turnos]
where Corporativo = 1
and Central ='cdmx'
and @Hora between CAST ( [Hora Inicio] AS TIME)   and  CAST ( [Hora Fin] AS TIME) 