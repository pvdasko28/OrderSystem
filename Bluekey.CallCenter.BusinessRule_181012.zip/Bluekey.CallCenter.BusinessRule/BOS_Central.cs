﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Central
    {
       
        public long Corporativo { get; set; }
       
        public string Central { get; set; }
       
        public string Nombre_Central { get; set; }

        public double Iva { get; set; }

        public double Servicio { get; set; }

        #region public methods

        public DataTable mgetConsultaCentral()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                dset = dao.ExecuteDataSet("bos_sp_central", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch
            {

            }
            return dtable;


        }

        #endregion
    }
}
