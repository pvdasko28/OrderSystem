﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Cliente : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOperador;
        string pTelefono;
        DateTime pHoraInicio;

        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                getLoadQS();
                populateMenu();
                populateDirecciones();
                populateSucursales();
            }
        }

        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];
        }

        private void populateMenu()
        {
            DataTable tblCorp= new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();
            
            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            frmCentral = tblCent.Rows[0]["Nombre Central"].ToString();


            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblClie = objOper.mgetConsultaOperador();
            frmOperador = tblClie.Rows[0]["Nombre"].ToString();

            BOS_Cliente objClie = new BOS_Cliente();
            objClie.Corporativo = pCorpo;
            objClie.Telefono_Cliente = pTelefono;
            tblClie = objClie.mgetConsultaClienteDirecciones();

            if (tblClie.Rows.Count > 0) 
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }
                                    
            frmTelefono = pTelefono;
            pHoraInicio = DateTime.Now;
            frmHoraIni = pHoraInicio.ToString ("hh:mm tt");

        }

        private void populateDirecciones()
        {
            BOS_Cliente objCliente = new BOS_Cliente();
            objCliente.Corporativo = pCorpo;
            objCliente.Telefono_Cliente = pTelefono;
            grdDir.DataSource = objCliente.mgetConsultaClienteDirecciones();
            grdDir.DataBind();
        }

        private void populateSucursales()
        {
            DataTable tblSuc = new DataTable();
            BOS_Sucursal objSuc = new BOS_Sucursal();
            objSuc.Corporativo = pCorpo;
            objSuc.Central = pCentral;
            objSuc.Sucursal = "";
            tblSuc = objSuc.mgetConsultaSucursales();

            ddlSuc.Items.Clear();
            ddlSuc.Items.Add(new ListItem { Text = "Seleccione Sucursal", Value = "" });
            ddlSuc.AppendDataBoundItems = true;
            ddlSuc.DataSource = tblSuc;
            ddlSuc.DataTextField = "Nombre Sucursal";
            ddlSuc.DataValueField = "Sucursal";
            ddlSuc.DataBind();



        }

        protected void ddlSuc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}