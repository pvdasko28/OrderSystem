﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Platillo
    {
        
        public long Corporativo { get; set; }
        
        public string Central { get; set; }
      
        public long Platillo { get; set; }
        
        public string Nombre_Platillo { get; set; }

        public long Grupo { get; set; }
       
        public string Clasificacion { get; set; }

        public double Servicio { get; set; }

        public long Comandera { get; set; }

        public bool Modificador { get; set; }
       
        public int Modificador_Cantidad { get; set; }

        public bool Terminador { get; set; }

        public int Tiempo { get; set; }
       
        public decimal Precio { get; set; }
        
        public bool Desglosa_Servicio { get; set; }

        public bool Paquete { get; set; }

        public bool Promocion { get; set; }
                
        public string Color { get; set; }

        public bool Activo { get; set; }


        #region public methods

        #endregion


    }
}
