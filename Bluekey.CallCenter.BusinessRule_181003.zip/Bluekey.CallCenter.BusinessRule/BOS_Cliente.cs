﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Cliente
    {

       
        public long Corporativo { get; set; }

        public long Id_Cliente { get; set; }

    
        public string Telefono_Cliente { get; set; }

        
        public string Telefono_Celular { get; set; }

      
        public string Telefono_Extra { get; set; }

        
        public string Nombre { get; set; }

       
        public string Apellido { get; set; }

        
        public string Email { get; set; }

      
        public DateTime? Fecha_Nacimiento { get; set; }

        #region publicMethods

        public DataTable mgetConsultaClienteDirecciones()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();
          
            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Telefono", this.Telefono_Cliente);
                dset = dao.ExecuteDataSet("bos_sp_clientesdirecciones", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch
            {

            }
            return dtable;


        }

        #endregion

    }
}
