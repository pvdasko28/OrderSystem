﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_PlatilloEquivalencia
    {
       
        public long Corporativo { get; set; }

      
        public string Central { get; set; }

       
        public long Platillo { get; set; }

       
        public string Descripcion { get; set; }

       
        public long Platillo_Equivalente { get; set; }

        #region public methods
        #endregion



    }
}
