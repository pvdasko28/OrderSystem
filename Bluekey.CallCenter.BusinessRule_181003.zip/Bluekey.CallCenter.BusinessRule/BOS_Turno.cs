﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Turno
    {

        
        public long Corporativo { get; set; }
        
        public string Central { get; set; }
        
        public int Turno { get; set; }
        
        public string Nombre_Turno { get; set; }
        
        public DateTime? Hora_Inicio { get; set; }
      
        public DateTime? Hora_Fin { get; set; }

        #region public methods
        #endregion
    }
}
