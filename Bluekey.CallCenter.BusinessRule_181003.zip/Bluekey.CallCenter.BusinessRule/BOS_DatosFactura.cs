﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_DatosFactura
    {
       
        public long Corporativo { get; set; }
       
        public string RFC { get; set; }
        
        public string Codigo_Postal { get; set; }
        
        public string Razon_Social { get; set; }
       
        public string Nombre_Comercial { get; set; }
       
        public string Calle { get; set; }
       
        public string No_Exterior { get; set; }
        
        public string No_Interior { get; set; }
              
        public string Colonia { get; set; }
       
        public string Municipio { get; set; }
        
        public string Estado { get; set; }
       
        public string Pais { get; set; }

        #region public methods
        #endregion

    }
}
