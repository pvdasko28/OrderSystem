﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Home : System.Web.UI.Page
    {
        String St_Mensaje = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            this.txtTel.Attributes.Add("onKeyPress", "return soloNumeros(event);");
        }

        protected void BtnSen_Click(object sender, EventArgs e)
        {

            try
            {
                Response.Redirect("Cliente.aspx?Corpo=" + txtIdc.Text + "&Central=" + txtCentral.Text + "&Oper=" + txtOper.Text + "&Tel=" + txtTel.Text);
            }
            catch (Exception Ex)
            {
                String A = Ex.Message;
                String B = Ex.Source;
                St_Mensaje = "Error al enviar parametros para orden \n" + A + "\n" + B;
                lblModalTitle.Text = "Error Order System";
                lblModalBody.Text = St_Mensaje;
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
                upModal.Update();
                throw;
            }

        }

        protected void BtnErr_Click(object sender, EventArgs e)
        {
            lblModalTitle.Text = "Error Order System";
            lblModalBody.Text = "Mensaje de prueba de error";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "myModal.modal('show');", true);
            upModal.Update();
        }

        protected void BtnPedido_Click(object sender, EventArgs e)
        {
            Response.Redirect("Orden?Corpo=1&Central=cdmx&Oper=1mx0004&Tel=5598273402&Suc=Cuau%20&IdCli=5&IdDir=1&HoraI=18:39%20a.%20m.&rfc=");
        }
    }
}