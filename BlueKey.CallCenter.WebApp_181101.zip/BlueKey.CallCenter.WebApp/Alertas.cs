﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BlueKey.CallCenter.WebApp
{
    public class Alertas
    {
        public enum AlertasType
        {
            Success,
            Info,
            Warning,
            Danger
        }
    }

   
}