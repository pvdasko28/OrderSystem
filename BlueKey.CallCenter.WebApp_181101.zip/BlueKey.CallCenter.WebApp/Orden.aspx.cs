﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Orden : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOperador;
        string pTelefono;
        string pSucursal;
        int pIdCliente;
        int pIdDireccion;
        string pRFC;
        DateTime pHoraInicio;
        int pTurno;
        int lineaOrden;
        int lineaPlatillo;
        string lineaNombrePlatillo;
        int lineaPaquete;
        decimal lineaPrecio;
        int clickGrupo;

        //List<BOS_OrdenDetalle> listaOrdenDetalle = new List<BOS_OrdenDetalle>();

        public List<BOS_OrdenDetalle> listaOrdenDetalle
        {
            get
            {
                if (HttpContext.Current.Session["listaOrdenDetalle"] == null)
                {
                    HttpContext.Current.Session["listaOrdenDetalle"] = new List<BOS_OrdenDetalle>();
                }
                return HttpContext.Current.Session["listaOrdenDetalle"] as List<BOS_OrdenDetalle>;
            }
            set
            {
                HttpContext.Current.Session["listaOrdenDetalle"] = value;
            }

        }

        #region variables forma

        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }

        private string frmGrupo;
        protected string _frmGrupo { get { return frmGrupo; } }

        private string frmBusqueda;
        protected string _frmBusqueda { get { return frmBusqueda; } }

        private string frmTotPla;
        protected string _frmTotPla { get { return frmTotPla; } }

        private string frmSubTot;
        protected string _frmSubTot { get { return frmSubTot; } }

        private string frmDesc;
        protected string _frmDesc { get { return frmDesc; } }

        private string frmIVA;
        protected string _frmIVA { get { return frmIVA; } }

        private string frmTotal;
        protected string _frmTotal { get { return frmTotal; } }

        #endregion


        protected void Page_Load(object sender, EventArgs e)
        {
            
            txtBusqueda.Attributes.Add("onkeypress", "return soloLetras(event)");

            if (!IsPostBack)
            {
                getLoadQS();               
                populateMenu();
                populateGenerales();
                obtieneTurno();
                generaBtnGrupos();
                generaBtnPlatillos();                

            }
            else
            {

                pCorpo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                pCentral = HttpContext.Current.Session["sCentral"].ToString();
                pOperador = HttpContext.Current.Session["sOperador"].ToString();
                pTelefono = HttpContext.Current.Session["sTelefono"].ToString();
                pSucursal = HttpContext.Current.Session["sSucursal"].ToString();
                pIdCliente = int.Parse(HttpContext.Current.Session["sIdCli"].ToString());
                pIdDireccion = int.Parse(HttpContext.Current.Session["sIdDir"].ToString());
                pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());
                pRFC = HttpContext.Current.Session["sRFC"].ToString();
                pTurno = int.Parse(HttpContext.Current.Session["sTurno"].ToString());

                generaBtnGrupos();
                generaBtnPlatillos();

                if (HttpContext.Current.Session["sClickGrupo"] != null)
                    generaBtnPlatillosGrupo();

                if (HttpContext.Current.Session["sClickBusqueda"] != null)
                {
                    foreach (Control item in pnlBusqueda.Controls.OfType<Button>())
                    {
                        pnlBusqueda.Controls.Remove(item);
                    }
                    generaBtnPlatilloBusqueda();
                }

                if (HttpContext.Current.Session["sEquivalencia"] != null)
                {
                    foreach (Control item in pnlEquivalencias.Controls.OfType<Button>())
                    {
                        pnlEquivalencias.Controls.Remove(item);
                    }
                    generaPlatilloEquivalencia(int.Parse(HttpContext.Current.Session["sEquivalencia"].ToString()));
                }
                
            }
        }

      
        #region populateMenu

        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];
            pSucursal = Request.QueryString["Suc"];
            pIdCliente = int.Parse(Request.QueryString["IdCli"].ToString());
            pIdDireccion = int.Parse(Request.QueryString["IdDir"].ToString());
            pHoraInicio = DateTime.Parse(Request.QueryString["HoraI"].ToString());
            pRFC = Request.QueryString["rfc"].ToString();


            Session["sCorpo"] = pCorpo;
            Session["sCentral"] = pCentral;
            Session["sOperador"] = pOperador;
            Session["sTelefono"] = pTelefono;
            Session["sSucursal"] = pSucursal;
            Session["sIdCli"] = pIdCliente;
            Session["sIdDir"] = pIdDireccion;
            Session["sHoraInicio"] = pHoraInicio;
            Session["sRFC"] = pRFC;

        }

        protected string ClientIDPageRedirect()
        {
            return this.paginaredirect.ClientID;
        }


        private void populateMenu()
        {
            DataTable tblCorp = new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();

            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            if (tblCorp.Rows.Count > 0)
                frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            if (tblClie.Rows.Count > 0)
                frmCentral = tblCent.Rows[0]["Nombre Central"].ToString();

            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblClie = objOper.mgetConsultaOperador();
            if (tblClie.Rows.Count > 0)
                frmOperador = tblClie.Rows[0]["Nombre"].ToString();

            BOS_ClienteDireccion objCli = new BOS_ClienteDireccion();
            objCli.Corporativo = pCorpo;
            objCli.Id_Cliente = pIdCliente;
            objCli.Id_Direccion = pIdDireccion;
            tblClie = objCli.mgetConsultaClienteDireccion();

            if (tblClie.Rows.Count > 0)
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString() + " " + tblClie.Rows[0]["Apellido"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }

            frmTelefono = pTelefono;
            pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());
            frmHoraIni = pHoraInicio.ToString("hh:mm tt");

        }

        private void populateGenerales()
        {
            DataTable dtable = new DataTable();
            BOS_Sucursal objSuc = new BOS_Sucursal();
            objSuc.Corporativo = pCorpo;
            objSuc.Central = pCentral;
            objSuc.Sucursal = pSucursal;
            dtable = objSuc.mgetConsultaSucursales();
            if (dtable.Rows.Count > 0)
            { 
                lblSucE.Text = dtable.Rows[0]["NombreSucursal"].ToString();
            
            }


        }

        private void obtieneTurno()
        {
            DataTable dtable = new DataTable();
            BOS_Turno objTurno = new BOS_Turno();
            objTurno.Corporativo = pCorpo;
            objTurno.Central = pCentral;
            objTurno.HoraTurno = pHoraInicio.ToString("yyyy-MM-dd HH:mm:ss");

            dtable = objTurno.mgetObtieneTurno();
            if (dtable.Rows.Count > 0)
            {
                pTurno = int.Parse(dtable.Rows[0]["Turno"].ToString());
                lblTurnoE.Text = dtable.Rows[0]["NombreTurno"].ToString();
                Session["sTurno"] = pTurno;
            }
            else
            {
                lblMsgAlert.Text = "<strong>No existen turnos disponibles en el horario actual, no se cargaran los grupos!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
        
        
        }

        #endregion

        private void generaBtnGrupos()
        {
           
            DataTable dtblTG = new DataTable();          
            BOS_TurnoGrupo objTurno = new BOS_TurnoGrupo();
            objTurno.Corporativo = pCorpo;
            objTurno.Central = pCentral;
            objTurno.Turno = pTurno;
            dtblTG = objTurno.mgetConsultaTurnosGrupos();
            if (dtblTG.Rows.Count > 0)
            {
                for (int i = 1; i <= dtblTG.Rows.Count - 1; i++)
                {

                    Button btnGpo = new Button();
                    btnGpo.Text = dtblTG.Rows[i]["NombreGrupo"].ToString();                    
                    btnGpo.ID = "G" + dtblTG.Rows[i]["Grupo"].ToString();
                    btnGpo.Font.Bold = true;
                    //btnGpo.ForeColor = System.Drawing.Color.White;
                    //btnGpo.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnGpo.Font.Size = 8;
                    btnGpo.CssClass = "btn btn-primary";
                    btnGpo.Width = Unit.Pixel(165);
                    btnGpo.Height = Unit.Pixel(30);                  
                    pnlGpo.Controls.Add(btnGpo);
                    pnlGpo.Visible = true;

                    if (i % 2 == 0 )
                    {
                        pnlGpo.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlGpo.Controls.Add(new LiteralControl("&nbsp;")); }

                    btnGpo.Click += new EventHandler(btnGpo_Click);

                }

                frmGrupo = "Platillos";
               

            }


        }

        void btnGpo_Click(object sender, EventArgs e)
        {          
           
            Button btn =  sender as Button;
            int longitud = btn.ID.Length ;
            int gpo = int.Parse(btn.ID.ToString().Substring(1, longitud -1));
            Session["sClickGrupo"] = gpo;
            Session["sNombregrupo"] = btn.Text;
            generaBtnPlatillosGrupo();           
            Session["sPanelAct"] = "divPGrupo";
            cambiaPanel();
        }

        private void generaBtnPlatillos()
        {
                      
            DataTable dtblTP = new DataTable();
            BOS_TurnoPlatillo objPlatillo = new BOS_TurnoPlatillo();
            objPlatillo.Corporativo = pCorpo;
            objPlatillo.Central = pCentral;
            objPlatillo.Turno = pTurno;
            dtblTP = objPlatillo.mgetConsultaTurnosPlatillo();
            if (dtblTP.Rows.Count > 0)
            {
            
                for (int i = 1; i <= dtblTP.Rows.Count -1; i++)
                {

                    Button btnPla = new Button();
                    btnPla.Text = dtblTP.Rows[i]["NombrePlatillo"].ToString();


                    btnPla.Font.Bold = true;
                    btnPla.ID = dtblTP.Rows[i]["Platillo"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnPla.Font.Size = 8;
                    btnPla.Width = Unit.Pixel(165);
                    btnPla.Height = Unit.Pixel(30);
                    btnPla.CssClass = "btn btn-success";
                    pnlPla.Controls.Add(btnPla);
                    pnlPla.Visible = true;
                    if (i % 2 == 0)
                    {
                        pnlPla.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlPla.Controls.Add(new LiteralControl("&nbsp;")); }
                    btnPla.Click += new EventHandler(btnPla_Click);

                }
            }
                       


        }

        void btnPla_Click(object sender, EventArgs e)
        {
            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int pla = int.Parse(btn.ID.ToString());
            bool paquete = false;
           
            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pla;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {
                paquete = bool.Parse(dtable.Rows[0]["Equivalencia"].ToString());

                if (paquete == true)
                { validaEstadoPlatillo(1, pla); }
                else { validaEstadoPlatillo(2, pla); }
                 
           

            //    lineaPlatillo =  int.Parse( dtable.Rows[0]["Platillo"].ToString());
            //    lineaNombrePlatillo = dtable.Rows[0]["NombrePlatillo"].ToString();
            //    lineaPaquete =0;
            //    lineaPrecio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());

            //    agregaOrdenDetalle();
            //    refreshGrdOrden();
            //    Session["sPanelAct"] = "divGpo";
            //    cambiaPanel();

            }


        }

        private void generaBtnPlatillosGrupo()
        {
            DataTable dtblPG = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            int gpo = int.Parse(Session["sClickGrupo"].ToString());
            frmGrupo = Session["sNombregrupo"].ToString();
            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = gpo;
            objPla.Platillo = 0;
            dtblPG = objPla.mgetConsultaPlatillosGrupo();
            if (dtblPG.Rows.Count > 0)
            {

                for (int i = 1; i <= dtblPG.Rows.Count-1; i++)
                {

                    Button btnPlaGpo = new Button();
                    btnPlaGpo.Text = dtblPG.Rows[i]["NombrePlatillo"].ToString();


                    btnPlaGpo.Font.Bold = true;
                    btnPlaGpo.ID = dtblPG.Rows[i]["Platillo"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnPlaGpo.Font.Size = 8;
                    btnPlaGpo.Width = Unit.Pixel(185);
                    btnPlaGpo.Height = Unit.Pixel(40);
                    btnPlaGpo.CssClass = "btn btn-info";
                    pnlPlatilloGpo.Controls.Add(btnPlaGpo);
                    pnlPlatilloGpo.Visible = true;
                    if (i % 2 == 0)
                    {
                        pnlPlatilloGpo.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlPlatilloGpo.Controls.Add(new LiteralControl("&nbsp;")); }
                    btnPlaGpo.Click += new EventHandler(btnPlaGpo_Click);

                }
            }
        }

        void btnPlaGpo_Click(object sender, EventArgs e)
        {
            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int pPlatillo = int.Parse(btn.ID.ToString());
            bool paquete = false;

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pPlatillo;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {
                               
                paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                if (paquete == true)
                {
                    validaEstadoPlatillo(1, pPlatillo);

                }
                else
                {
                    validaEstadoPlatillo(2, pPlatillo);
                }


                

                //if (equivalencia > 0 || terminador == true || modificador == true || paquete == true || promocion == true)
                //{
                //    Session["sClickBusqueda"] = null;
                //    Session["sEquivalencia"] = null;
                //    validaSecuencia(pla, terminador, modificador, paquete, promocion);
                //}
                //else
                //{ 

                //    lineaPlatillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                //    lineaNombrePlatillo = dtable.Rows[0]["NombrePlatillo"].ToString();
                //    lineaPaquete = 0;
                //    lineaPrecio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());

                //    agregaOrdenDetalle();
                //    refreshGrdOrden();                
                //    Session["sClickGrupo"] = null;
                //    Session["sNombregrupo"] = null;
                //    frmGrupo = "Platillo";
                //    Session["sPanelAct"] = "divGpo";
                //    cambiaPanel();
                //}
            }

       

        }

        private void agregaOrden()
        {
            var objOrden = new BOS_Orden()
            {
                Corporativo = pCorpo,
                Central = pCentral,
                Orden = 1,
                Sucursal = pSucursal,
                Id_Cliente = pIdCliente,
                Id_Direccion = pIdDireccion,
                Comensales = 1,
                Turno = pTurno,
                Nota = "",
                Origen = "",
                Forma_Pago = "",
                Fecha_Captura_Inicio = pHoraInicio.ToString(),
                Operador_Captura = pOperador,
                Fecha_Captura_Fin = DateTime.Now.ToString(),
                Promesa_Entrega ="",
                Estatus="",
                Repartidor=0,
                Usuario_Cancela="",
                Fecha_Cancela="",
                Nota_Cancela="",
                RFC="",
                Codigo_Postal=""
                
            };

            Session["slistOrden"] = objOrden;
        
        }

        private void agregaOrdenDetalle()
        {
            BOS_OrdenDetalle ordenNueva = new BOS_OrdenDetalle();

            if (HttpContext.Current.Session["sLineaOrden"] != null)
            {
                lineaOrden = int.Parse(Session["sLineaOrden"].ToString());
                lineaOrden++;
            }
            else {
                lineaOrden = 1;
            }
            
                        
            ordenNueva.Corporativo = pCorpo;
            ordenNueva.Central = pCentral;
            ordenNueva.Linea = lineaOrden;
            ordenNueva.Platillo = lineaPlatillo;
            ordenNueva.Nombre_Platillo = lineaNombrePlatillo;
            ordenNueva.Cantidad = 1;
            ordenNueva.Precio = lineaPrecio;
            ordenNueva.Nota_Platillo = "";
            ordenNueva.Terminador = 1;
            ordenNueva.Precio_Neto = lineaPrecio;
            ordenNueva.Servicio = 0;
            ordenNueva.Descuento = 0;
            ordenNueva.Descuento_Porcentaje = 0;
            ordenNueva.Fecha_Captura_Platillo = DateTime.Now.ToString();
            ordenNueva.Activo = true;
            ordenNueva.Usuario_Cancela = "";
            ordenNueva.Fecha_Cancela = "";
            ordenNueva.Nota_Cancela = "";

            listaOrdenDetalle.Add(ordenNueva);
            Session["sLineaOrden"] = lineaOrden;

            sumaTotales(lineaPrecio);
        }

        private void sumaTotales(decimal Precio)
        {
            decimal sumaTot = 0;
            int totpla = 0;
            if (HttpContext.Current.Session["sTotal"] !=null)
                sumaTot = decimal.Parse( HttpContext.Current.Session["sTotal"].ToString());
            sumaTot = sumaTot + Precio;
            Session["sTotal"] = sumaTot;
            frmTotal = sumaTot.ToString();

            if (HttpContext.Current.Session["sTotPla"] !=null)
                totpla = int.Parse(HttpContext.Current.Session["sTotPla"].ToString());
            totpla++;
            Session["sTotPla"] = totpla;
            frmTotPla = totpla.ToString();

            frmSubTot = "0";
            frmIVA = "0";
            frmDesc = "0";
        }

        private void refreshGrdOrden()
        {
            grdCaptura.DataSource = listaOrdenDetalle;
            grdCaptura.DataBind();
            
        }

        protected void btnOrden_Click(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["sRFC"] != null)
            { pRFC = HttpContext.Current.Session["sRFC"].ToString(); }
            else { pRFC = ""; }

            if (pRFC == "")
            {
                lblMsgAlert.Text = "<strong>Debe seleccionar un RFC!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
            else
            {
                Response.Redirect("Orden.aspx?Corpo=" + pCorpo.ToString() + "&Central=" + pCentral + " &Oper=" + pOperador + "&Suc=" + pSucursal + " &IdCli=" + pIdCliente.ToString() + "&IdDir=" + pIdDireccion.ToString() + "&HoraI=" + pHoraInicio.ToString("hh:mm tt") + "&rfc=" + pRFC);
            }

        }


        protected void btnBuscar_Click(object sender, ImageClickEventArgs e)
        {
            Session["sBusqueda"] = null;
            if (txtBusqueda.Text != "")
            {
                // validar que la busqueda sea diferente o hacer algo
                generaBtnPlatilloBusqueda();

                if ( bool.Parse( HttpContext.Current.Session["sBusqueda"].ToString()) == false)
                {                       
                    frmBusqueda = "No se encontraron coincidencias con su busqueda <strong>" + txtBusqueda.Text + "</strong>";
                    Session["sPanelAct"] = "divBusqueda";
                    cambiaPanel();

                } else { 

                    Session["sClickBusqueda"] = true;
                    Session["sPanelAct"] = "divBusqueda";
                    cambiaPanel();
                }
            }
            else {

                Session["sClickBusqueda"] = null;
                lblMsgAlert.Text = "<strong>Capture un platillo a buscar!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
        }


        private void generaBtnPlatilloBusqueda()
        {
            DataTable dtblPG = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Turno = pTurno;
            objPla.Nombre_Platillo = txtBusqueda.Text;

            dtblPG = objPla.mgetConsultaPlatillosNombre();
            if (dtblPG.Rows.Count > 0)
            {

                for (int i = 0; i <= dtblPG.Rows.Count-1; i++)
                {
                    Button btnBusqueda = new Button();
                    btnBusqueda.Text = dtblPG.Rows[i]["NombrePlatillo"].ToString();


                    btnBusqueda.Font.Bold = true;
                    btnBusqueda.ID = "B" + dtblPG.Rows[i]["Platillo"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnBusqueda.Font.Size = 8;
                    btnBusqueda.Width = Unit.Pixel(165);
                    btnBusqueda.Height = Unit.Pixel(30);
                    btnBusqueda.CssClass = "btn btn-warning";
                    pnlBusqueda.Controls.Add(btnBusqueda);
                    pnlBusqueda.Visible = true;
                    if (i % 2 != 0)
                    {
                        pnlBusqueda.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlBusqueda.Controls.Add(new LiteralControl("&nbsp;")); }
                    btnBusqueda.Click += new EventHandler(btnBusqueda_Click);                   
                }

                Session["sBusqueda"] = true;
            }
            else
            {
                Session["sBusqueda"] = false;
            }
        }


        void btnBusqueda_Click(object sender, EventArgs e)
        {
            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(1, longitud-1));           
            bool paquete =false;

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pPlatillo;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {
                paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());

                if (paquete == true)
                { validaEstadoPlatillo(1, pPlatillo); }
                else 
                {
                    Session["sEquivalencia"] = pPlatillo;
                    validaEstadoPlatillo(2, pPlatillo); 
                }

                //Valida equivalencias, terminador , modificador
                //equivalencia = int.Parse(dtable.Rows[0]["Equivalencia"].ToString());
                //terminador = bool.Parse(dtable.Rows[0]["Terminador"].ToString());
                //modificador = bool.Parse(dtable.Rows[0]["Modificador"].ToString());
                //paquete = bool.Parse(dtable.Rows[0]["Paquete"].ToString());
                //promocion = bool.Parse(dtable.Rows[0]["Promocion"].ToString());



                //if (equivalencia > 0 || terminador == true || modificador== true || paquete==true || promocion==true)
                //{
                //    Session["sClickBusqueda"] = null;
                //    generaPlatilloEquivalencia(pla);                   
                //}
                //else
                //{


                //    lineaPlatillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                //    lineaNombrePlatillo = dtable.Rows[0]["NombrePlatillo"].ToString();
                //    lineaPaquete = 0;
                //    lineaPrecio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());

                //    agregaOrdenDetalle();
                //    refreshGrdOrden();
                //    Session["sPanelAct"] = "divGpo";
                //    cambiaPanel();
                //    Session["sClickBusqueda"] = null;
                //    txtBusqueda.Text = "";
                //}
            }

          
            

        }

        private void generaPlatilloEquivalencia(int pPlatillo)
        {
            //1er proceso  
            DataTable dtable = new DataTable();
            BOS_PlatilloEquivalencia objEqui = new BOS_PlatilloEquivalencia();
            objEqui.Corporativo = pCorpo;
            objEqui.Central = pCentral;
            objEqui.Platillo = pPlatillo;
            dtable = objEqui.mgetEquivalenciasPlatillo();
            if (dtable.Rows.Count > 0)
            {

                for (int i = 0; i <= dtable.Rows.Count - 1; i++)
                {
                    Button btnEquivalencia = new Button();
                    btnEquivalencia.Text = dtable.Rows[i]["NombrePlatillo"].ToString();


                    btnEquivalencia.Font.Bold = true;
                    btnEquivalencia.ID = "E" + dtable.Rows[i]["PlatilloEquivalente"].ToString();
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnEquivalencia.Font.Size = 8;
                    btnEquivalencia.Width = Unit.Pixel(165);
                    btnEquivalencia.Height = Unit.Pixel(30);
                    btnEquivalencia.CssClass = "btn btn-warning";
                    pnlEquivalencias.Controls.Add(btnEquivalencia);
                    pnlEquivalencias.Visible = true;
                    if (i % 2 != 0)
                    {
                        pnlEquivalencias.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlEquivalencias.Controls.Add(new LiteralControl("&nbsp;")); }
                    btnEquivalencia.Click += new EventHandler(btnEquivalencia_Click);
                }

                this.modalExtEquivalencias.Show();
                //Session["sEquivalencia"] = pPlatillo;
                //Session["sPanelAct"] = "divEquivalencia";
                //cambiaPanel();


            }



           
        }


        void btnEquivalencia_Click(object sender, EventArgs e)
        {
            DataTable dtable = new DataTable();
            BOS_Platillo objPla = new BOS_Platillo();
            Button btn = sender as Button;
            int longitud = btn.ID.Length;
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(1, longitud - 1));          
            bool terminador = false;

            objPla.Corporativo = pCorpo;
            objPla.Central = pCentral;
            objPla.Grupo = 0;
            objPla.Platillo = pPlatillo;
            dtable = objPla.mgetConsultaPlatillosGrupo();
            if (dtable.Rows.Count > 0)
            {
                //terminador , modificador                
                terminador = bool.Parse(dtable.Rows[0]["Terminador"].ToString());

                this.modalExtTerminadores.Hide(); 
                if ( terminador == true )
                {
                    
                    validaEstadoPlatillo(3, pPlatillo);
                }
                else
                {
                  
                    validaEstadoPlatillo(4, pPlatillo);
                    //lineaPlatillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                    //lineaNombrePlatillo = dtable.Rows[0]["NombrePlatillo"].ToString();
                    //lineaPaquete = 0;
                    //lineaPrecio = decimal.Parse(dtable.Rows[0]["Precio"].ToString());

                    //agregaOrdenDetalle();
                    //refreshGrdOrden();
                    //Session["sPanelAct"] = "divGpo";
                    //cambiaPanel();

                }
            }

            
          
        }

        private void validaEstadoPlatillo(int pEstado, int pPlatillo)
        {
            switch (pEstado)
            {
                //paquete
                case 1:
                    generaPlatilloPaquete(pPlatillo);
                    break;

                // equivalencias
                case 2:
                    generaPlatilloEquivalencia(pPlatillo);
                    break;

                //terminadores
                case 3:
                    generaPlatilloTerminadores (pPlatillo);
                    break;

                //modificadores 
                case 4:
                    generaPlatilloModificadores(pPlatillo);
                    break;

                //promociones
                case 5:
                    generaPlatilloPromociones(pPlatillo);
                    break;

                //agrega orden
                case 6:
                    agregaOrdenDetalle();
                    refreshGrdOrden();
                    break;

                default:
                    break;

            }
        }
        
        private void generaPlatilloPaquete(int pPlatillo)
        {
            //Estado: 1           
            int equivalencia;
            DataTable dtable = new DataTable();
            BOS_Paquete objPaq = new BOS_Paquete();
            objPaq.Corporativo = pCorpo;
            objPaq.Central = pCentral;
            objPaq.Platillo = pPlatillo;
            dtable = objPaq.mgetConsultaPaquete();

            if (dtable.Rows.Count > 0)
            {

                for (int i = 1; i <= dtable.Rows.Count - 1; i++)
                {
                    pPlatillo = int.Parse(dtable.Rows[0]["Platillo"].ToString());
                    equivalencia = int.Parse(dtable.Rows[0]["Equivalencia"].ToString());

                    if (equivalencia > 1)
                    { validaEstadoPlatillo(2, pPlatillo); }
                    else { validaEstadoPlatillo(3, pPlatillo);  }

                    
                }


            }


        }

        private void generaPlatilloTerminadores(int pPlatillo)
        {
            DataTable dtable = new DataTable();
            BOS_Terminador objTerm = new BOS_Terminador();
            objTerm.Corporativo = pCorpo;
            objTerm.Central = pCentral;
            dtable = objTerm.mgetConsultaTerminador();

            if (dtable.Rows.Count > 0)
            {

                for (int i = 0; i <= dtable.Rows.Count - 1; i++)
                {
                    Button btnTerminador = new Button();
                    btnTerminador.Text = dtable.Rows[i]["NombreTerminador"].ToString();


                    btnTerminador.Font.Bold = true;
                    btnTerminador.ID = "T" + dtable.Rows[i]["Terminador"].ToString() + "_" + pPlatillo;
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnTerminador.Font.Size = 8;
                    btnTerminador.Width = Unit.Pixel(165);
                    btnTerminador.Height = Unit.Pixel(30);
                    btnTerminador.CssClass = "btn btn-primary";
                    pnlTerminadores.Controls.Add(btnTerminador);
                    pnlTerminadores.Visible = true;
                    if (i % 2 != 0)
                    {
                        pnlTerminadores.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlTerminadores.Controls.Add(new LiteralControl("&nbsp;")); }
                    btnTerminador.Click += new EventHandler(btnTerminador_Click);
                }
                this.modalExtTerminadores.Show();

            }
            else
            { 
             
                this.modalExtTerminadores.Hide();
                validaEstadoPlatillo(4, pPlatillo);
          
            }
        }

        void btnTerminador_Click(object sender, EventArgs e)
        {
           
            Button btn = sender as Button;
            int longitud = btn.ID.Length;           
            int ip = btn.ID.IndexOf("_");
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(ip, longitud-1));       
            this.modalExtTerminadores.Hide();
            validaEstadoPlatillo(4, pPlatillo);
        }

        private void generaPlatilloModificadores(int pPlatillo)
        {
            DataTable dtable = new DataTable();
            BOS_Modificador objMod = new BOS_Modificador();
            objMod.Corporativo = pCorpo;
            objMod.Central = pCentral;
            objMod.Grupo = 0;
            objMod.Clasificacion = "";
            dtable = objMod.mgetConsultaModificador();

            if (dtable.Rows.Count > 0)
            {

                for (int i = 0; i <= dtable.Rows.Count - 1; i++)
                {
                    Button btnModificador = new Button();
                    btnModificador.Text = dtable.Rows[i]["NombreModificador"].ToString();


                    btnModificador.Font.Bold = true;
                    btnModificador.ID = "M" + dtable.Rows[i]["Modificador"].ToString() + "_" + pPlatillo;
                    //btnPla.ForeColor = System.Drawing.Color.White;
                    //btnPla.BackColor = System.Drawing.Color.LightSteelBlue;
                    btnModificador.Font.Size = 8;
                    btnModificador.Width = Unit.Pixel(165);
                    btnModificador.Height = Unit.Pixel(30);
                    btnModificador.CssClass = "btn btn-primary";
                    pnlModificadores.Controls.Add(btnModificador);
                    pnlModificadores.Visible = true;
                    if (i % 2 != 0)
                    {
                        pnlModificadores.Controls.Add(new LiteralControl("<div class=\"clearfix\"></div></br>"));
                    }
                    else { pnlModificadores.Controls.Add(new LiteralControl("&nbsp;")); }
                    btnModificador.Click += new EventHandler(btnModificador_Click);
                }
                this.modalExtModificadores.Show();

            }
            else
            {
                this.modalExtTerminadores.Hide();
                validaEstadoPlatillo(5, pPlatillo);
            }
           
        }

        void btnModificador_Click(object sender, EventArgs e)
        {
             Button btn = sender as Button;
            int longitud = btn.ID.Length;           
            int ip = btn.ID.IndexOf("_");
            int pPlatillo = int.Parse(btn.ID.ToString().Substring(ip, longitud-1));       
            this.modalExtTerminadores.Hide();
            this.modalExtModificadores.Hide();
            validaEstadoPlatillo(5, pPlatillo);
        
        }

        private void generaPlatilloPromociones(int pPlatillo)
        {
            validaEstadoPlatillo(6, pPlatillo);
        }

        private void cambiaPanel()
        {
            string panelactivo;
            panelactivo = Session["sPanelAct"].ToString();
          
            switch (panelactivo)
            {
                case "divGpo":
                    divGpo.Attributes["class"] = "tab-pane fade in active";
                    divPGrupo.Attributes["class"] = "tab-pane fade";
                    divPTurno.Attributes["class"] = "tab-pane fade";
                    divBusqueda.Attributes["class"] = "tab-pane fade";                 
                    break;

                case "divPGrupo":
                    divGpo.Attributes["class"] = "tab-pane fade";
                    divPGrupo.Attributes["class"] = "tab-pane fade in active";
                    divPTurno.Attributes["class"] = "tab-pane fade";
                    divBusqueda.Attributes["class"] = "tab-pane fade";                  
                    break;

                case "divPTurno":
                    divGpo.Attributes["class"] = "tab-pane fade";
                    divPGrupo.Attributes["class"] = "tab-pane fade";
                    divPTurno.Attributes["class"] = "tab-pane fade in active";
                    divBusqueda.Attributes["class"] = "tab-pane fade";                   
                    break;

                case "divBusqueda":
                    divGpo.Attributes["class"] = "tab-pane fade";
                    divPGrupo.Attributes["class"] = "tab-pane fade";
                    divPTurno.Attributes["class"] = "tab-pane fade";
                    divBusqueda.Attributes["class"] = "tab-pane fade in active";
                    break;

               
                default:
                    divGpo.Attributes["class"] = "tab-pane fade in active";
                    divPGrupo.Attributes["class"] = "tab-pane fade";
                    divPTurno.Attributes["class"] = "tab-pane fade";
                    divBusqueda.Attributes["class"] = "tab-pane fade";                  
                    break;
            }


        }

        private void showMessage(string msgA, string msgB, string St_Mensaje)
        {
            St_Mensaje = St_Mensaje + "\n" + msgA + "\n" + msgB;
            lblModalTitleError.Text = "Bluekey Order System";
            lblModalBodyError.Text = St_Mensaje;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModalError').modal();", true);
            upModalError.Update();

        }

    }
}