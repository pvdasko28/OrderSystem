﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Cliente : System.Web.UI.Page
    {
        int pCorpo;
        string pCentral;
        string pOperador;
        string pTelefono;
        string pSucursal;
        DateTime pHoraInicio;
        int pIdCliente;
        int pIdDireccion;

        private string frmCorpo;
        protected string _frmCorpo { get { return frmCorpo; } }

        private string frmCentral;
        protected string _frmCentral { get { return frmCentral; } }

        private string frmTelefono;
        protected string _frmTelefono { get { return frmTelefono; } }

        private string frmOperador;
        protected string _frmOperador { get { return frmOperador; } }

        private string frmCliente;
        protected string _frmCliente { get { return frmCliente; } }

        private string frmHoraIni;
        protected string _frmHoraIni { get { return frmHoraIni; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getLoadQS();
                populateMenu();
                populateDirecciones();
                populateSucursales();
                //populateFechaNac();
            }
            else
            {

                pCorpo = int.Parse(HttpContext.Current.Session["sCorpo"].ToString());
                pCentral = HttpContext.Current.Session["sCentral"].ToString();
                pOperador = HttpContext.Current.Session["sOperador"].ToString();
                pTelefono = HttpContext.Current.Session["sTelefono"].ToString();
                pHoraInicio = DateTime.Parse(HttpContext.Current.Session["sHoraInicio"].ToString());              

            }
        }

        private void getLoadQS()
        {
            pCorpo = int.Parse(Request.QueryString["Corpo"].ToString());
            pCentral = Request.QueryString["Central"];
            pOperador = Request.QueryString["Oper"];
            pTelefono = Request.QueryString["Tel"];

            Session["sCorpo"] = pCorpo;
            Session["sCentral"] = pCentral;
            Session["sOperador"] = pOperador;
            Session["sTelefono"] = pTelefono;


        }

        private void populateMenu()
        {
            DataTable tblCorp = new DataTable();
            DataTable tblCent = new DataTable();
            DataTable tblOper = new DataTable();
            DataTable tblClie = new DataTable();

            BOS_Corporativo objCorp = new BOS_Corporativo();
            objCorp.Corporativo = pCorpo;
            tblCorp = objCorp.mgetConsultaCorporativo();
            if (tblCorp.Rows.Count > 0)
            {
                frmCorpo = tblCorp.Rows[0]["Nombre Corporativo"].ToString();
            } else { frmCorpo = "No se pudo obtener corporativo"; }
                

            BOS_Central objCent = new BOS_Central();
            objCent.Corporativo = pCorpo;
            objCent.Central = pCentral;
            tblCent = objCent.mgetConsultaCentral();
            if (tblCent.Rows.Count > 0)
            { frmCentral = tblCent.Rows[0]["Nombre Central"].ToString(); }
            else { frmCentral = "No se pudo ontener central"; }
            

            BOS_Operador objOper = new BOS_Operador();
            objOper.Corporativo = pCorpo;
            objOper.Central = pCentral;
            objOper.Operador = pOperador;
            tblOper = objOper.mgetConsultaOperador();
            if (tblOper.Rows.Count > 0 ) 
            {
                frmOperador = tblOper.Rows[0]["Nombre"].ToString();
            }
            else { frmOperador = "No se pudo obtener operador"; }
           

            BOS_Cliente objClie = new BOS_Cliente();
            objClie.Corporativo = pCorpo;
            objClie.Telefono_Cliente = pTelefono;
            tblClie = objClie.mgetConsultaClienteDirecciones();

            if (tblClie.Rows.Count > 0)
            {
                frmCliente = tblClie.Rows[0]["Nombre"].ToString();
            }
            else { frmCliente = "<strong>Registrar Cliente!</strong>"; }

            frmTelefono = pTelefono;

            if (pHoraInicio != null)
                pHoraInicio = DateTime.Now;


            Session["sHoraInicio"] = pHoraInicio.ToString("hh:mm tt");
            frmHoraIni = pHoraInicio.ToString("hh:mm tt");


        }

        private void populateDirecciones()
        {
            BOS_Cliente objCliente = new BOS_Cliente();
            objCliente.Corporativo = pCorpo;
            objCliente.Telefono_Cliente = pTelefono;
            grdDir.DataSource = objCliente.mgetConsultaClienteDirecciones();
            grdDir.DataBind();
        }

        private void populateSucursales()
        {
            DataTable tblSuc = new DataTable();
            BOS_Sucursal objSuc = new BOS_Sucursal();
            objSuc.Corporativo = pCorpo;
            objSuc.Central = pCentral;
            objSuc.Sucursal = "";
            tblSuc = objSuc.mgetConsultaSucursales();

            if (tblSuc.Rows.Count >0)
            { 

                ddlSuc.Items.Clear();
                ddlSuc.Items.Add(new ListItem { Text = "Seleccione Sucursal", Value = "" });
                ddlSuc.AppendDataBoundItems = true;
                ddlSuc.DataSource = tblSuc;
                ddlSuc.DataTextField = "NombreSucursal";
                ddlSuc.DataValueField = "Sucursal";
                ddlSuc.DataBind();
            }


        }
        //private void populateFechaNac()
        //{


        //    ddlDia.Items.Clear();
        //    ddlDia.Items.Add(new ListItem { Text = "Dia", Value = "" });
        //    for (int  i = 1; i<32; i++ )
        //    {
        //        ddlDia.Items.Add(new ListItem { Text = i.ToString(), Value = i.ToString() });
        //    }

        //    ddlMes.Items.Clear();
        //    ddlMes.Items.Add(new ListItem { Text = "Mes",      Value = "" });
        //    ddlMes.Items.Add(new ListItem { Text = "Enero",    Value = "01" });
        //    ddlMes.Items.Add(new ListItem { Text = "Febrero",  Value = "02" });
        //    ddlMes.Items.Add(new ListItem { Text = "Marzo",    Value = "03" });
        //    ddlMes.Items.Add(new ListItem { Text = "Abril",    Value = "04" });
        //    ddlMes.Items.Add(new ListItem { Text = "Mayo",     Value = "05" });
        //    ddlMes.Items.Add(new ListItem { Text = "Junio",    Value = "06" });
        //    ddlMes.Items.Add(new ListItem { Text = "Julio",    Value = "07" });
        //    ddlMes.Items.Add(new ListItem { Text = "Agosto",   Value = "08" });
        //    ddlMes.Items.Add(new ListItem { Text = "Septiembre",Value = "09" });
        //    ddlMes.Items.Add(new ListItem { Text = "Octubre",  Value = "10" });
        //    ddlMes.Items.Add(new ListItem { Text = "Noviembre",Value = "11" });
        //    ddlMes.Items.Add(new ListItem { Text = "Diciembre",Value = "12" });


        //    int aniofin = 0;
        //    aniofin = int.Parse(DateTime.Now.Year.ToString());
        //    ddlAnio.Items.Clear();
        //    ddlAnio.Items.Add(new ListItem { Text = "Año", Value = "" });
        //    for (int k = 1900; k < aniofin - 10; k++)
        //    {
        //        ddlAnio.Items.Add(new ListItem { Text = k.ToString (), Value = k.ToString()});

        //    }

        //}

        protected void ddlSuc_SelectedIndexChanged(object sender, EventArgs e)
        {
            pSucursal = ddlSuc.SelectedItem.Value.ToString();
            Session["sSucursal"] = pSucursal;

            if (pSucursal == "")
            {
                lblMsgAlert.Text = "<strong>Debe seleccionar una sucursal!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Warning.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
            else {            

                lblMsgAlert.Text ="Envio a sucursal: <strong>" + ddlSuc.SelectedItem.Text  + "</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Info.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {

            int idCliente = 0;
            int idClienteDireccion = 0;
            BOS_Cliente objCliente = new BOS_Cliente();
            BOS_ClienteDireccion objCliDir = new BOS_ClienteDireccion();
            pSucursal = HttpContext.Current.Session["sSucursal"].ToString();

            try
            {
                objCliente.Corporativo = pCorpo;
                objCliente.Telefono_Cliente = pTelefono;
                objCliente.Telefono_Celular = txtCel.Text;
                objCliente.Telefono_Extra = txtTel.Text;
                objCliente.Nombre = txtNombre.Text;
                objCliente.Apellido = txtApellido.Text;
                objCliente.Email = txtEmail.Text;
                objCliente.Fecha_Nacimiento = txtFec.Text;
                idCliente = objCliente.insertaCliente();
                Session["sIdCli"] = idCliente;

                objCliDir.Corporativo = pCorpo;
                objCliDir.Id_Cliente = idCliente;
                objCliDir.Codigo_Postal = txtCP.Text;
                objCliDir.Calle = txtCalle.Text;
                objCliDir.No_Exterior = txtNumE.Text;
                objCliDir.No_Interior = txtNumI.Text;
                objCliDir.Colonia = txtCol.Text;
                objCliDir.Municipio = txtMpio.Text;
                objCliDir.Estado = txtEdo.Text;
                objCliDir.Entre_Calles = txtEnt.Text;
                objCliDir.Referencia = txtRef.Text;
                idClienteDireccion = objCliDir.insertaClienteDireccion();
                Session["sIdDir"] = idClienteDireccion;


                lblMsgAlert.Text = "Cliente registrado: <strong>" + txtNombre.Text + " " + txtApellido.Text + "</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Success.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
            catch (Exception Ex)
            {
                String A = Ex.Message;
                String B = Ex.Source;
                showMessage(A, B, "Error al insertar datos del Cliente");

            }


        }

        private void showMessage(string msgA, string msgB, string title)
        {
            String St_Mensaje = "";
            St_Mensaje = "Error al insertar datos cliente \n" + msgA + "\n" + msgB;
            lblModalTitle.Text = "Bluekey Order System";
            lblModalBody.Text = St_Mensaje;
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            upModal.Update();

        }

        protected void btnOrden_Click(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["sSucursal"] != null)
            { pSucursal = HttpContext.Current.Session["sSucursal"].ToString(); }
            else { pSucursal = ""; }
            if (HttpContext.Current.Session["sIdCli"] != null)
            { pIdCliente = int.Parse(HttpContext.Current.Session["sIdCli"].ToString()); }
            else { pIdCliente = 0; }
            if (HttpContext.Current.Session["sIdDir"] != null)
            { pIdDireccion = int.Parse(HttpContext.Current.Session["sIdDir"].ToString()); }
            else { pIdDireccion = 0; }
            

            if (pIdCliente == 0 && pIdDireccion == 0)
            {
                lblMsgAlert.Text = "<strong>Debe seleccionar una cliente!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");
            }
            else if (pSucursal == "" || pSucursal == null)
            {
                lblMsgAlert.Text = "<strong>Debe seleccionar una sucursal!</strong>";
                Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Danger.ToString().ToLower());
                Message.Attributes.Add("role", "alert");                
            }
            else
            {

                Response.Redirect("DatosFiscales.aspx?Corpo=" + pCorpo.ToString () + "&Central=" + pCentral + "&Oper=" + pOperador + "&Tel="+ pTelefono + "&Suc=" + pSucursal + " &IdCli=" + pIdCliente.ToString() + "&IdDir=" + pIdDireccion.ToString() + "&HoraI=" + pHoraInicio.ToString("hh:mm tt"));
                //Response.Redirect("DatosFiscales.aspx?Corpo=1&Central=cdmx&Oper=1mx0004&Tel=88&Suc=Sate&IdCli=8&IdDir=1&HoraI=" + pHoraInicio.ToString("hh:mm tt"));
            }

           
        }

        private void limpiaInputs()
        {


            txtCel.Text = "";
            txtTel.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtEmail.Text = "";
            txtFec.Text = "";
            txtCP.Text = "";
            txtCalle.Text = "";
            txtNumE.Text = "";
            txtNumI.Text = "";
            txtCol.Text = "";
            txtMpio.Text = "";
            txtEdo.Text = "";
            txtEnt.Text = "";
            txtRef.Text = "";
            ddlSuc.ClearSelection();


        }

        protected void grdDir_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int idCliente;
            int idDireccion;

            limpiaInputs();

            DataTable tblClie = new DataTable();

            GridViewRow row = grdDir.SelectedRow;
            idCliente = int.Parse(row.Cells[0].Text);
            idDireccion = int.Parse(row.Cells[1].Text);

            try
            {

                BOS_ClienteDireccion objClie = new BOS_ClienteDireccion();
                objClie.Corporativo = pCorpo;
                objClie.Id_Cliente = idCliente;
                objClie.Id_Direccion = idDireccion;
                tblClie = objClie.mgetConsultaClienteDireccion();

                if (tblClie.Rows.Count > 0)
                {
                    pIdCliente = int.Parse(tblClie.Rows[0]["idCliente"].ToString());
                    pIdDireccion = int.Parse(tblClie.Rows[0]["idDireccion"].ToString());
                    txtCel.Text = tblClie.Rows[0]["TelefonoCelular"].ToString();
                    txtTel.Text = tblClie.Rows[0]["TelefonoExtra"].ToString();
                    txtNombre.Text = tblClie.Rows[0]["Nombre"].ToString();
                    txtApellido.Text = tblClie.Rows[0]["Apellido"].ToString();
                    txtEmail.Text = tblClie.Rows[0]["Email"].ToString();
                    txtFec.Text = tblClie.Rows[0]["FechaNacimiento"].ToString();
                    txtCP.Text = tblClie.Rows[0]["CP"].ToString();
                    txtCalle.Text = tblClie.Rows[0]["Calle"].ToString();
                    txtNumE.Text = tblClie.Rows[0]["NoExt"].ToString();
                    txtNumI.Text = tblClie.Rows[0]["NoInt"].ToString();
                    txtCol.Text = tblClie.Rows[0]["Colonia"].ToString();
                    txtMpio.Text = tblClie.Rows[0]["Municipio"].ToString();
                    txtEdo.Text = tblClie.Rows[0]["Estado"].ToString();
                    txtEnt.Text = tblClie.Rows[0]["EntreCalles"].ToString();
                    txtRef.Text = tblClie.Rows[0]["Referencia"].ToString();

                    Session["sIdCli"] = pIdCliente;
                    Session["sIdDir"] = pIdDireccion;

                    lblMsgAlert.Text = "Selecciono  los datos de: <strong>" + tblClie.Rows[0]["Nombre"].ToString() + " " + tblClie.Rows[0]["Apellido"].ToString() +"</strong>";
                    Message.CssClass = String.Format("alert alert-{0} alert-dismissable", Alertas.AlertasType.Success.ToString().ToLower());
                    Message.Attributes.Add("role", "alert");

                }
                else
                {
                    showMessage("", "", "Error al cargar datos del Cliente");
                }
            }
            catch (Exception Ex)
            {
                String A = Ex.Message;
                String B = Ex.Source;
                showMessage(A, B, "Error al cargar datos del Cliente");

            }


        }


        

    }
}